#ifndef SIMULATION_INCLUDED
#define SIMULATION_INCLUDED


#include "readFile.h"


void simulations(Nodes *nodes_head, Event *event_head);

void UpdateTypesCosts(Nodes *nodes_head);

void CleanAns(Nodes *listHead);

#endif //SIMULATION INCLUDED